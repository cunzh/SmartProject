

var requestRrepairMsg={
	url: "../../product/add.action",
	callbackMethod:submitInfoResult,
	data:""
};


 var requestProductTypeMsg = {
    url: "../../producttype/get.action",
    callbackMethod: setProductTypeSelect,
    data: ""
};

 var requestProductPropertyMsg = {
    url: "../../productproperty/get.action",
    callbackMethod: setProductPropertySelect,
    data: ""
};



var ProductTypeID = "";
//alert(ProductTypeID);
$(document).ready(function() {

		getProductTypeData();


	$("#button_submmit").click(function() {
		submitRepairData();
	});

	$("#button_reset").click(function() {
		$("#preview").text("");
		$("#button_submmit1").removeAttr("disabled");
	});

	$('#product_type').change(function () {
		ProductTypeID = $(this).children('option:selected').val();
		alert("你所选择的商品类型是："+ProductTypeID);
		getProductPropertyData();			
			});

	

});


function getProductTypeData()
{
	
	getData(requestProductTypeMsg);

}


function setProductTypeSelect(data) { 
	//alert("商品类型默认值"+ProductTypeID);
		fillSelect(data,"#product_type");
		}


 function getProductPropertyData()
 {
	 

 var postData = {"productPropertyId":ProductTypeID};

	 requestProductPropertyMsg.data = postData;
	 
	getData(requestProductPropertyMsg);
 
 }


function setProductPropertySelect(data) {
	
	//alert("商品属性是"+ProductTypeID);
	$("#product_property").empty();
		   fillSelect(data,"#product_property");
		}


function initTypeSelect() {

    // 房号select数据
    var producttype = new Array("1", "2", "3");

    for (var i = 0; i < producttype.length; i++) {
        $("#product_type").append(
				"<option value='" +producttype[i] + "'>" +producttype[i] + "</option>");
    }

}




//提交报修信息
function submitRepairData() {

	 var title = $("#product_title").val();

    var type = $("#product_type").val();
	var property = $("#product_property").val();

    var price = $("#product_price").val();

    //var freight = $("#product_freight").val();
    //var address = $("#product_address").val();
    var content = $("#product_content").val();
   

    var im = $("#imagesid").val();

	var shopId = 3;

	alert("商品类别是"+type);
	alert("商品属性是"+property);

	alert("商店号是"+shopId);


	var formData = new FormData($("#uploadForm")[0]);

	//alert(formData['repair.devicename']+"ppppp");

	requestRrepairMsg.data=formData;

	//getData(requestRrepairMsg);

	getDataWithFileUpload(requestRrepairMsg);
}

function submitInfoResult(result)
{
	if(result.success == true)
	{
		alert("提交信息成功");
	} 
	else
	{
		alert("提交信息失败  " + result.type);
	}
	
}